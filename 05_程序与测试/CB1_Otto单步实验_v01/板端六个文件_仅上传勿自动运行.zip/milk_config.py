# Edit on PC, then re-upload. Defaults intentionally forbid gait PWM.
CALIBRATED = False
REMOTE_MAPPING_VERIFIED = False
# Supply and pin order must be checked separately from the program.
# S1=GPIO3 S2=GPIO2 S3=GPIO1 S4=GPIO0.
JOINTS = [
    dict(name='left_hip', pin=3, center=90, trim=0, direction=1, min=65, max=115),
    dict(name='right_hip', pin=2, center=90, trim=0, direction=1, min=65, max=115),
    dict(name='left_ankle', pin=1, center=90, trim=0, direction=1, min=65, max=115),
    dict(name='right_ankle', pin=0, center=90, trim=0, direction=1, min=65, max=115),
]
PULSE_AT_0_US = 500
PULSE_AT_180_US = 2500
HIP = 8
LEAN = 7
LIFT = 3
PHASE_MS = 450
LEFT_SIGN = 1  # Determine with supported, small-angle weight-shift test.
# Official rc tuple: L1,L2,L3,R1,R2,R3,K1,K2,K3,K4
LEFT_CHANNEL = 0   # Proposed L1; verify with milk_probe.monitor()
RIGHT_CHANNEL = 3  # Proposed R1
LEFT_CENTER = 2048
RIGHT_CENTER = 2048
LEFT_SPAN = 1800
RIGHT_SPAN = 1800
LEFT_DIRECTION = 1
RIGHT_DIRECTION = 1
ATTACK_BUTTON = 6  # K1 proposed
ENABLE_BUTTON = 7  # K2 hold one second while neutral
STOP_BUTTON = 8    # K3 optional dedicated stop
BUTTON_ACTIVE = 0 # Verify actual button polarity!
LINK_TIMEOUT_MS = 250
LOOP_MS = 20
# Never enable until wiring, servo type, stop pulse and clearance verified.
ATTACK_ENABLED = False
ATTACK_PIN = 21    # D1 signal candidate; not a power pin.
ATTACK_MODE = 'position'  # 'position' PG001; 'continuous' only verified type.
ATTACK_REST_US = 1500
ATTACK_HIT_US = 1650
ATTACK_STOP_US = 1500
ATTACK_RUN_US = 1580
ATTACK_MAX_MS = 700
